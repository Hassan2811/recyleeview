package com.ninedtech.recviewproj;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MobileAdapter extends RecyclerView.Adapter<MobileAdapter.vuholder> {

    ArrayList<MoibleModel> listofmobiles;
    Dialog dialogs;


    public MobileAdapter(ArrayList<MoibleModel> listofmobiles) {
        this.listofmobiles = listofmobiles;

    }


    @NonNull

    @Override
    public vuholder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.customlayout,parent,false);
        return new vuholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MobileAdapter.vuholder holder, int position) {
      //  MoibleModel mmodel=listofmobiles.get(position);
        holder.ivu.setImageResource(listofmobiles.get(position).getPicofmob());
        holder.tvnam.setText(listofmobiles.get(position).getMname());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button yesbtn,nobtn;
                Toast.makeText(v.getContext(), "Hi",Toast.LENGTH_SHORT).show();

               // AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());

                dialogs= new Dialog(v.getContext());
                dialogs.setContentView(R.layout.cdbox);
                dialogs.show();

                yesbtn = dialogs.findViewById(R.id.btnyes);
                nobtn=dialogs.findViewById(R.id.btnno);


                yesbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listofmobiles.remove(position);
                        notifyItemRemoved(position);

                    }
                });

                nobtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogs.dismiss();
                    }
                });
                // Get the layout inflater
               // LayoutInflater inflater = v.getContext().getLayoutInflater();

                // Inflate and set the layout for the dialog
                // Pass null as the parent view because its going in the dialog layout
               // builder.setView(inflater.inflate(R.layout.cdbox, null))*/




               /* AlertDialog.Builder bodybuilder =new AlertDialog.Builder(v.getRootView().getContext());
                View dialogs=LayoutInflater.from(v.getRootView().getContext()).inflate(R.layout.cdbox,null);
                bodybuilder.setView(dialogs);

                bodybuilder.show();

                Button yesbtn,nobtn;

                yesbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(yesbtn.getContext(),"Fir Soch lo",Toast.LENGTH_SHORT ).show();

                        listofmobiles.remove(position);
                        notifyItemRemoved(position);
                    }
                });
                nobtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });



*/



            }
        });


       /* holder.ivu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"You clicked on Image",Toast.LENGTH_SHORT).show();
            }
        });

        holder.tvnam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "You clicked on text",Toast.LENGTH_SHORT).show();
            }
        });*/


        
    }

    @Override
    public int getItemCount() {
        return listofmobiles.size();

    }

    public class vuholder extends RecyclerView.ViewHolder {
        ImageView ivu;
        TextView tvnam;
        public vuholder(@NonNull  View itemView) {
            super(itemView);
            ivu=itemView.findViewById(R.id.imgvu);
            tvnam=itemView.findViewById(R.id.tvname);
        }
    }
}

