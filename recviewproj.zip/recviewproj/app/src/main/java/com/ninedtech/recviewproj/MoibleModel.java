package com.ninedtech.recviewproj;

public class MoibleModel {

    int picofmob;
    String mname;

    public MoibleModel(int picofmob, String mname) {
        this.picofmob = picofmob;
        this.mname = mname;
    }

    public int getPicofmob() {
        return picofmob;
    }

    public void setPicofmob(int picofmob) {
        this.picofmob = picofmob;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }
}
