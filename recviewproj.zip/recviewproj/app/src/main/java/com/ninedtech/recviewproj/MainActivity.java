package com.ninedtech.recviewproj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView myrecvu;
    ArrayList<MoibleModel> listmob;
    int noofcolmns=2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listmob=new ArrayList<>();
        myrecvu=findViewById(R.id.myrecview);


        listmob.add(new MoibleModel(R.drawable.m1,"Samsung s3"));
        listmob.add(new MoibleModel(R.drawable.m2,"Huawei P8 Lite"));
        listmob.add(new MoibleModel(R.drawable.m3,"Samsung s6"));
        listmob.add(new MoibleModel(R.drawable.m4,"Iphone 5"));
        listmob.add(new MoibleModel(R.drawable.m5,"Huawi mate 10"));
        listmob.add(new MoibleModel(R.drawable.m6,"Samsung s9"));
        listmob.add(new MoibleModel(R.drawable.m7,"Dummy"));
        listmob.add(new MoibleModel(R.drawable.m8,"11 Pro Max"));
        listmob.add(new MoibleModel(R.drawable.m9,"Dummy 2"));
        //myrecvu.setLayoutManager(new GridLayoutManager(this, noofcolmns));
        MobileAdapter mobadaptr=new MobileAdapter(listmob);
        myrecvu.setAdapter(mobadaptr);
        myrecvu.setHasFixedSize(true);
        myrecvu.setItemViewCacheSize(listmob.size());




        // set a LinearLayoutManager with default orientation
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        myrecvu.setLayoutManager((new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false))); // set LayoutManager to RecyclerView*/


    }
}